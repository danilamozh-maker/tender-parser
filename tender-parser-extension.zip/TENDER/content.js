// content.js — выполняется на странице zakupki.gov.ru

// ===== ИЗВЛЕЧЕНИЕ НОМЕРА ЗАКУПКИ ИЗ URL =====
function extractRegNumber(url) {
    const match = url.match(/regNumber=([\d]+)/);
    if (match) return match[1];
    const match2 = url.match(/purchaseNoticeNumber=([\d]+)/);
    if (match2) return match2[1];
    return null;
}

// ===== ИЗВЛЕЧЕНИЕ ТЕКСТА ИЗ МОДАЛЬНОГО ОКНА =====
function extractTextFromModal() {
    const content = document.querySelector('.print-form-content') || 
                    document.querySelector('.notice-body') || 
                    document.querySelector('.content') ||
                    document.body;
    return content.innerText || '';
}

// ===== ОТКРЫТИЕ СТРАНИЦЫ И ИЗВЛЕЧЕНИЕ ТЕКСТА =====
async function fetchTenderText(regNumber) {
    const url = `https://zakupki.gov.ru/epz/order/notice/printForm/listModal.html?regNumber=${regNumber}`;
    
    try {
        const tab = await chrome.tabs.create({ url: url, active: false });
        await new Promise(resolve => setTimeout(resolve, 5000));
        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: extractTextFromModal
        });
        await chrome.tabs.remove(tab.id);
        return results[0]?.result || '';
    } catch (e) {
        console.error('Ошибка при извлечении текста:', e);
        return '';
    }
}

// ===== СБОР ССЫЛОК НА ТЕНДЕРЫ (УНИВЕРСАЛЬНЫЙ СЕЛЕКТОР) =====
function collectTenders() {
    const tenderUrls = [];
    
    // Ищем ВСЕ ссылки, которые содержат regNumber или purchaseNoticeNumber
    const links = document.querySelectorAll('a[href*="regNumber="], a[href*="purchaseNoticeNumber="]');
    
    links.forEach(link => {
        let href = link.getAttribute('href');
        if (href && !href.startsWith('http')) {
            href = 'https://zakupki.gov.ru' + href;
        }
        // Проверяем, что ссылка уникальная и содержит номер закупки
        if (href && !tenderUrls.includes(href)) {
            tenderUrls.push(href);
        }
    });
    
    return tenderUrls;
}

// ===== НОВАЯ ФУНКЦИЯ: ИЗВЛЕЧЕНИЕ ДАННЫХ 223-ФЗ ИЗ СТРАНИЦЫ =====
function extract223Data() {
    let noticeNumber = null;
    let guid = null;

    // 1. Пытаемся найти номер в элементе с атрибутами или классами
    const numberEl = document.querySelector('[data-notice-number], .notice-number, .purchase-notice-number, .regNumber');
    if (numberEl) {
        noticeNumber = numberEl.textContent.trim();
    }

    // 2. Если не нашли – ищем в тексте по шаблону "Извещение № XXXX"
    if (!noticeNumber) {
        const bodyText = document.body.innerText;
        const match = bodyText.match(/Извещение\s*№\s*(\d+)/i) || bodyText.match(/№\s*(\d+)/);
        if (match) noticeNumber = match[1];
    }

    // 3. Извлекаем GUID из атрибутов
    const guidAttr = document.querySelector('[data-guid], [data-notice-guid]');
    if (guidAttr) {
        guid = guidAttr.getAttribute('data-guid') || guidAttr.getAttribute('data-notice-guid');
    }

    // 4. Если GUID не найден – ищем в ссылках на странице
    if (!guid) {
        const links = document.querySelectorAll('a[href*="purchaseNoticeGuid="]');
        for (const link of links) {
            const match = link.href.match(/purchaseNoticeGuid=([a-f0-9\-]+)/);
            if (match) {
                guid = match[1];
                break;
            }
        }
    }

    // 5. Если всё ещё нет – ищем любой GUID в тексте
    if (!guid) {
        const bodyText = document.body.innerText;
        const guidMatch = bodyText.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
        if (guidMatch) guid = guidMatch[0];
    }

    return { noticeNumber, guid };
}

// ===== ОБРАБОТКА СООБЩЕНИЙ ОТ POPUP =====
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'collectTenders') {
        const urls = collectTenders();
        sendResponse({ tenderUrls: urls });
    }
    // Новый обработчик для запроса данных 223
    if (request.action === 'get223Data') {
        const data = extract223Data();
        sendResponse(data);
    }
    return true;
});

console.log('content.js загружен (универсальный селектор + извлечение 223)');
