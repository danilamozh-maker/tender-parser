// ============================================================
// ПОЛНЫЙ POPUP.JS — СТАБИЛЬНЫЙ DEVICE_ID (КАК В WINDOWS)
// ============================================================

// ===== ЛИЦЕНЗИЯ И ПРОБНЫЙ ПЕРИОД =====

const LICENSE_SERVER = 'https://danilamozh-maker-tender-parser-4c53.twc1.net';
const FETCH_TIMEOUT = 10000;
const RETRY_COUNT = 2;

async function fetchWithTimeout(url, options = {}, timeout = FETCH_TIMEOUT, retries = RETRY_COUNT) {
    let lastError;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), timeout);
            const response = await fetch(url, { ...options, signal: controller.signal });
            clearTimeout(timeoutId);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            return response;
        } catch (e) {
            lastError = e;
            console.warn(`⚠️ Попытка ${attempt + 1} из ${retries + 1} не удалась:`, e.message);
            if (attempt < retries) {
                await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1)));
            }
        }
    }
    throw lastError || new Error('Не удалось выполнить запрос после нескольких попыток');
}

function showInterface(showMain) {
    const activation = document.getElementById('activationSection');
    const main = document.getElementById('mainInterface');
    if (activation) activation.style.display = showMain ? 'none' : 'block';
    if (main) main.className = showMain ? '' : 'hidden';
}

function updateLicenseStatus(isTrial, expiresAt, trialEnd) {
    const statusEl = document.getElementById('licenseStatus');
    const expiresEl = document.getElementById('expiresLabel');
    if (!statusEl || !expiresEl) {
        console.warn('⚠️ Элементы статуса не найдены в DOM');
        return;
    }
    if (isTrial) {
        statusEl.textContent = '🔓 Пробный период';
        expiresEl.textContent = '';
    } else {
        statusEl.textContent = '✅ Лицензия активна';
        if (expiresAt) {
            const date = new Date(expiresAt);
            if (!isNaN(date.getTime())) {
                expiresEl.textContent = `до: ${date.toLocaleDateString()}`;
            } else {
                expiresEl.textContent = `до: ${expiresAt}`;
            }
        } else {
            expiresEl.textContent = '';
        }
    }
}

// ===== ГЕНЕРАЦИЯ СТАБИЛЬНОГО DEVICE_ID (КАК В WINDOWS) =====
async function getDeviceId() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['stable_device_id'], async (result) => {
            if (result.stable_device_id) {
                console.log('🔑 Найден существующий stable_device_id:', result.stable_device_id);
                resolve(result.stable_device_id);
                return;
            }

            try {
                const stableId = await generateStableDeviceId();
                chrome.storage.local.set({ stable_device_id: stableId }, () => {
                    console.log('🆕 Сгенерирован stable_device_id:', stableId);
                    resolve(stableId);
                });
            } catch (e) {
                const fallback = 'device_' + Date.now() + '_' + Math.random().toString(36).substring(2, 10);
                chrome.storage.local.set({ stable_device_id: fallback }, () => {
                    console.log('⚠️ Использован fallback device_id:', fallback);
                    resolve(fallback);
                });
            }
        });
    });
}

async function generateStableDeviceId() {
    const components = {
        platform: navigator.platform,
        userAgent: navigator.userAgent,
        language: navigator.language,
        languages: navigator.languages ? navigator.languages.join(',') : '',
        hardwareConcurrency: navigator.hardwareConcurrency || 0,
        deviceMemory: navigator.deviceMemory || 0,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        screenWidth: screen.width,
        screenHeight: screen.height,
        colorDepth: screen.colorDepth,
        canvas: await getCanvasFingerprint(),
        fonts: await getFontFingerprint()
    };

    const json = JSON.stringify(components);
    const encoder = new TextEncoder();
    const data = encoder.encode(json);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return 'device_' + hashHex.substring(0, 32);
}

function getCanvasFingerprint() {
    return new Promise((resolve) => {
        try {
            const canvas = document.createElement('canvas');
            canvas.width = 200;
            canvas.height = 50;
            const ctx = canvas.getContext('2d');
            ctx.textBaseline = 'top';
            ctx.font = '14px Arial';
            ctx.fillStyle = '#f60';
            ctx.fillRect(125, 1, 62, 20);
            ctx.fillStyle = '#069';
            ctx.fillText('TenderParser', 2, 15);
            ctx.fillStyle = 'rgba(102, 204, 0, 0.7)';
            ctx.fillText('Fingerprint', 4, 17);
            const dataUrl = canvas.toDataURL();
            resolve(dataUrl);
        } catch (e) {
            resolve('');
        }
    });
}

function getFontFingerprint() {
    return new Promise((resolve) => {
        try {
            const testFonts = [
                'Arial', 'Verdana', 'Times New Roman', 'Courier New',
                'Helvetica', 'Georgia', 'Tahoma', 'Trebuchet MS',
                'Comic Sans MS', 'Impact'
            ];
            const baseFont = 'serif';
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = 100;
            canvas.height = 50;
            ctx.font = '20px ' + baseFont;
            const baseWidth = ctx.measureText('abcdefghijklmnopqrstuvwxyz').width;
            const available = [];
            for (const font of testFonts) {
                ctx.font = '20px ' + font + ', ' + baseFont;
                const width = ctx.measureText('abcdefghijklmnopqrstuvwxyz').width;
                if (width !== baseWidth) {
                    available.push(font);
                }
            }
            resolve(available.join(','));
        } catch (e) {
            resolve('');
        }
    });
}

// ===== ПОЛУЧЕНИЕ ЛИЦЕНЗИОННОГО КЛЮЧА =====
async function getLicenseKey() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['license_key'], (result) => {
            resolve(result.license_key || null);
        });
    });
}

async function getAuthHeaders() {
    const deviceId = await getDeviceId();
    const licenseKey = await getLicenseKey();
    const headers = {
        'X-Device-ID': deviceId
    };
    if (licenseKey) {
        headers['X-License-Key'] = licenseKey;
    }
    return headers;
}

async function checkTrial() {
    const device_id = await getDeviceId();
    console.log('📤 Проверка пробного периода dla device_id:', device_id);
    try {
        const response = await fetchWithTimeout(`${LICENSE_SERVER}/api/trial/status`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ device_id })
        });
        const data = await response.json();
        console.log('📥 Ответ сервера (пробный период):', data);
        return data;
    } catch (e) {
        console.error('❌ Ошибка проверки пробного периода:', e);
        return { status: 'error', error: e.message };
    }
}

async function startTrial() {
    const device_id = await getDeviceId();
    console.log('📤 Активация пробного периода dla device_id:', device_id);
    try {
        const response = await fetchWithTimeout(`${LICENSE_SERVER}/api/trial/start`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ device_id })
        });
        const data = await response.json();
        console.log('📥 Ответ сервера (старт пробного периода):', data);
        return data;
    } catch (e) {
        console.error('❌ Ошибка старта пробного периода:', e);
        return null;
    }
}

async function checkLicense() {
    return new Promise(async (resolve) => {
        chrome.storage.local.get(['license_key', 'license_expires'], async (result) => {
            const key = result.license_key;
            const expires = result.license_expires;
            console.log('🔍 Проверка локальной лицензии:', { key, expires });

            if (key && expires) {
                if (new Date(expires) < new Date()) {
                    console.log('⏰ Срок лицензии истёк локально');
                    const trialStatus = await checkTrial();
                    if (trialStatus.status === 'active') {
                        console.log('✅ Пробный период активен');
                        resolve({ trial: true, trialEnd: trialStatus.trial_end });
                        return;
                    }
                    resolve(null);
                    return;
                }
                try {
                    const headers = await getAuthHeaders();
                    const response = await fetchWithTimeout(`${LICENSE_SERVER}/api/verify-license`, {
                        method: 'POST',
                        headers: { ...headers, 'Content-Type': 'application/json' },
                        body: JSON.stringify({ key })
                    });
                    const data = await response.json();
                    console.log('📥 Ответ сервера (лицензия):', data);
                    if (response.ok && data.valid) {
                        resolve({ key, expires: data.expires_at });
                        return;
                    } else {
                        console.log('⚠️ Лицензия невалидна на сервере');
                        const trialStatus = await checkTrial();
                        if (trialStatus.status === 'active') {
                            console.log('✅ Пробный период активен');
                            resolve({ trial: true, trialEnd: trialStatus.trial_end });
                            return;
                        }
                        resolve(null);
                        return;
                    }
                } catch (e) {
                    console.error('❌ Ошибка проверки лицензии на сервере:', e);
                    resolve({ key, expires });
                    return;
                }
            }

            console.log('🔑 Лицензия не найдена, проверяем пробный период...');
            const trialStatus = await checkTrial();
            console.log('📊 Статус пробного периода:', trialStatus);

            if (trialStatus.status === 'active') {
                console.log('✅ Пробный период активен');
                resolve({ trial: true, trialEnd: trialStatus.trial_end });
            } else if (trialStatus.status === 'not_started') {
                console.log('🆕 Пробный период не начат, активируем...');
                await startTrial();
                const updatedStatus = await checkTrial();
                if (updatedStatus.status === 'active') {
                    resolve({ trial: true, trialEnd: updatedStatus.trial_end });
                } else {
                    resolve(null);
                }
            } else {
                resolve(null);
            }
        });
    });
}

async function verifyOnServer(key) {
    try {
        const response = await fetchWithTimeout(`${LICENSE_SERVER}/api/verify-license`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ key })
        });
        const data = await response.json();
        return data;
    } catch (e) {
        console.error('❌ Ошибка проверки лицензии:', e);
        return { valid: false };
    }
}

async function activateLicense(key) {
    const status = document.getElementById('activationStatus');
    if (!status) return;
    status.textContent = '⏳ Проверка...';
    status.className = '';

    try {
        console.log('📤 Активация лицензии:', key);
        const response = await fetchWithTimeout(`${LICENSE_SERVER}/api/activate-license`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ key })
        });
        const data = await response.json();
        console.log('📥 Ответ сервера (активация):', data);

        if (response.ok && data.valid) {
            chrome.storage.local.set({
                license_key: key,
                license_expires: data.expires_at
            }, () => {
                console.log('✅ Лицензия сохранена локально');
                status.textContent = '✅ Лицензия активирована!';
                status.className = 'success';
                showInterface(true);
                updateLicenseStatus(false, data.expires_at);
                document.getElementById('licenseInput').value = '';
            });
        } else {
            let msg = '❌ Недействительный ключ';
            if (data.reason === 'expired') msg = '❌ Ключ истёк';
            else if (data.reason === 'already_used') msg = '❌ Ключ уже активирован на другом устройстве';
            else if (data.reason === 'not_found') msg = '❌ Ключ не найден';
            status.textContent = msg;
            status.className = 'error';
        }
    } catch (e) {
        console.error('❌ Ошибка активации:', e);
        status.textContent = '❌ Ошибка соединения с сервером';
        status.className = 'error';
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    console.log('🚀 Расширение загружено');

    const license = await checkLicense();
    console.log('🔍 Результат проверки:', license);

    if (license) {
        if (license.trial) {
            console.log('🔓 Пробный период активен');
            showInterface(true);
            updateLicenseStatus(true, null, license.trialEnd);
            const status = document.getElementById('activationStatus');
            if (status) {
                status.textContent = '✅ Пробный период активен';
                status.className = 'success';
            }
        } else {
            console.log('✅ Лицензия активна');
            showInterface(true);
            updateLicenseStatus(false, license.expires);
            const status = document.getElementById('activationStatus');
            if (status) {
                status.textContent = '✅ Лицензия активна';
                status.className = 'success';
            }
        }
    } else {
        console.log('❌ Нет доступа');
        showInterface(false);
        const status = document.getElementById('activationStatus');
        if (status) {
            status.textContent = '⏰ Пробный период истёк или лицензия не найдена. Введите ключ.';
            status.className = 'error';
        }
    }
});

document.getElementById('activateBtn')?.addEventListener('click', () => {
    const key = document.getElementById('licenseInput').value.trim().toUpperCase();
    if (!key) {
        const status = document.getElementById('activationStatus');
        if (status) {
            status.textContent = '⚠️ Введите ключ';
            status.className = 'error';
        }
        return;
    }
    activateLicense(key);
});

document.getElementById('activateLicenseBtn')?.addEventListener('click', () => {
    showInterface(false);
    const status = document.getElementById('activationStatus');
    if (status) {
        status.textContent = '';
        status.className = '';
    }
    const input = document.getElementById('licenseInput');
    if (input) {
        input.value = '';
        input.focus();
    }
});

// ============================================================
// УПРАВЛЕНИЕ ЧЕК-ЛИСТОМ
// ============================================================

function updateSelectAllButton() {
    const checkboxes = document.querySelectorAll('.field-checkbox');
    const allChecked = Array.from(checkboxes).every(cb => cb.checked);
    const btn = document.getElementById('selectAllBtn');
    if (!btn) return;
    if (allChecked) {
        btn.classList.remove('inactive');
        btn.classList.add('active');
        btn.textContent = '✅ Выбрать все';
    } else {
        btn.classList.remove('active');
        btn.classList.add('inactive');
        btn.textContent = '⬜ Выбрать все';
    }
}

document.getElementById('selectAllBtn')?.addEventListener('click', () => {
    const checkboxes = document.querySelectorAll('.field-checkbox');
    const allChecked = Array.from(checkboxes).every(cb => cb.checked);
    checkboxes.forEach(cb => cb.checked = !allChecked);
    updateSelectAllButton();
});

document.getElementById('deselectAllBtn')?.addEventListener('click', () => {
    document.querySelectorAll('.field-checkbox').forEach(cb => cb.checked = false);
    updateSelectAllButton();
});

document.querySelectorAll('.field-checkbox').forEach(cb => {
    cb.addEventListener('change', updateSelectAllButton);
});

function getSelectedFields() {
    const checkboxes = document.querySelectorAll('.field-checkbox:checked');
    const fields = [];
    checkboxes.forEach(cb => fields.push(cb.value));
    return fields;
}

// ============================================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ДЛЯ РАБОТЫ С ТЕНДЕРАМИ
// ============================================================

function extractRegNumber(url) {
    const match = url.match(/regNumber=([\d]+)/);
    if (match) return match[1];
    const match2 = url.match(/purchaseNoticeNumber=([\d]+)/);
    if (match2) return match2[1];
    return null;
}

function extractPurchaseNoticeNumber(url) {
    let match = url.match(/purchaseNoticeNumber=([\d]+)/);
    if (match) return match[1];
    match = url.match(/noticeNumber=([\d]+)/);
    if (match) return match[1];
    const pathMatch = url.match(/\/notice\/([\d]+)/);
    if (pathMatch) return pathMatch[1];
    return null;
}

function extractPurchaseNoticeGuid(url) {
    let match = url.match(/purchaseNoticeGuid=([a-f0-9\-]+)/);
    if (match) return match[1];
    match = url.match(/noticeGuid=([a-f0-9\-]+)/);
    if (match) return match[1];
    match = url.match(/guid=([a-f0-9\-]+)/);
    if (match) return match[1];
    const guidMatch = url.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
    if (guidMatch) return guidMatch[0];
    return null;
}

function getTenderType(url) {
    if (url.includes('notice223')) return '223';
    if (url.includes('/223/') || url.includes('purchaseNoticeNumber=')) return '223';
    if (url.includes('regNumber=') && url.includes('/epz/order/')) return '44';
    if (url.includes('regNumber=')) return '223';
    return 'unknown';
}

function extractTextFromModal() {
    const selectors = [
        '.print-form-content',
        '.notice-body',
        '.content',
        '.view-content',
        '.main-content',
        '.modal-body',
        '.modal-content',
        '.popup-content',
        '#printFormContainer',
        'body'
    ];
    for (const selector of selectors) {
        const el = document.querySelector(selector);
        if (el && el.innerText && el.innerText.length > 100) {
            return el.innerText;
        }
    }
    return document.body.innerText || '';
}

function buildPrintFormUrl44(url) {
    const regNumber = extractRegNumber(url);
    if (!regNumber) {
        console.warn('⚠️ Не удалось извлечь regNumber для 44-ФЗ из URL:', url);
        return null;
    }
    return `https://zakupki.gov.ru/epz/order/notice/printForm/view.html?regNumber=${regNumber}`;
}

async function fetchTenderTextByUrl(formUrl) {
    let tab = null;
    try {
        tab = await chrome.tabs.create({ url: formUrl, active: false });
        await new Promise(resolve => setTimeout(resolve, 4000));
        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: extractTextFromModal
        });
        const text = results[0]?.result || '';
        console.log(`📄 Текст извлечён (${text.length} символов)`);
        return text;
    } catch (e) {
        console.error('❌ Ошибка при извлечении текста:', e);
        return '';
    } finally {
        if (tab) {
            try { await chrome.tabs.remove(tab.id); } catch (e) { /* вкладка уже закрыта */ }
        }
    }
}

async function detectExtensionFromBlob(blob) {
    const buffer = await blob.slice(0, 30).arrayBuffer();
    const bytes = new Uint8Array(buffer);
    const hex = Array.from(bytes.slice(0, 12)).map(b => b.toString(16).padStart(2, '0')).join(' ');
    console.log(`🔎 Первые байты файла: ${hex}`);

    if (bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46) return '.pdf';
    if (bytes[0] === 0x50 && bytes[1] === 0x4B) return '.zip';
    if (bytes[0] === 0x52 && bytes[1] === 0x61 && bytes[2] === 0x72 && bytes[3] === 0x21 && bytes[4] === 0x1A && bytes[5] === 0x07 && bytes[6] === 0x00) return '.rar';
    if (bytes[0] === 0x52 && bytes[1] === 0x61 && bytes[2] === 0x72 && bytes[3] === 0x21 && bytes[4] === 0x1A && bytes[5] === 0x07 && bytes[6] === 0x01 && bytes[7] === 0x00) return '.rar';
    if (bytes[0] === 0x52 && bytes[1] === 0x61 && bytes[2] === 0x72 && bytes[3] === 0x21) return '.rar';
    if (bytes[0] === 0x37 && bytes[1] === 0x7A && bytes[2] === 0xBC && bytes[3] === 0xAF && bytes[4] === 0x27 && bytes[5] === 0x1C) return '.7z';
    if (bytes[0] === 0xD0 && bytes[1] === 0xCF && bytes[2] === 0x11 && bytes[3] === 0xE0) return '.xls';
    if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4E && bytes[3] === 0x47) return '.png';
    if (bytes[0] === 0xFF && bytes[1] === 0xD8 && bytes[2] === 0xFF) return '.jpg';
    if (bytes[0] === 0x7B && bytes[1] === 0x5C && bytes[2] === 0x72 && bytes[3] === 0x74 && bytes[4] === 0x66) return '.rtf';
    return '';
}

function getExtensionFromMimeType(mimeType) {
    const map = {
        'application/pdf': '.pdf',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
        'application/vnd.ms-excel': '.xls',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
        'application/msword': '.doc',
        'application/zip': '.zip',
        'application/x-rar-compressed': '.rar',
        'image/jpeg': '.jpg',
        'image/png': '.png',
        'image/gif': '.gif',
        'text/plain': '.txt',
        'application/json': '.json',
        'application/xml': '.xml',
        'text/xml': '.xml'
    };
    return map[mimeType] || '';
}

async function fetchAllFiles(tenderUrl, extraParams = {}) {
    const regNumber = extractRegNumber(tenderUrl);
    const type = getTenderType(tenderUrl);
    let docsUrl;

    if (type === '44') {
        if (!regNumber) {
            console.warn('⚠️ Не удалось извлечь номер закупки dla 44-ФЗ');
            return [];
        }
        docsUrl = `https://zakupki.gov.ru/epz/order/notice/ezt20/view/documents.html?regNumber=${regNumber}`;
    } else if (type === '223') {
        let noticeNumber = extraParams.noticeNumber || null;
        let guid = extraParams.guid || null;
        if (!noticeNumber || !guid) {
            noticeNumber = extractPurchaseNoticeNumber(tenderUrl);
            guid = extractPurchaseNoticeGuid(tenderUrl);
        }
        if (noticeNumber && guid) {
            docsUrl = `https://zakupki.gov.ru/epz/order/notice/notice223/documents.html?purchaseNoticeNumber=${noticeNumber}&noticeGuid=${guid}`;
        } else if (regNumber) {
            docsUrl = `https://zakupki.gov.ru/epz/order/notice/notice223/documents.html?regNumber=${regNumber}`;
        } else {
            console.warn('⚠️ Не удалось извлечь параметры для документов 223-ФЗ');
            return [];
        }
    } else {
        console.warn('⚠️ Неизвестный тип закупки dla документов');
        return [];
    }

    console.log(`📂 Загружаем страницу документов: ${docsUrl}`);

    try {
        const tab = await chrome.tabs.create({ url: docsUrl, active: false });
        await new Promise(resolve => setTimeout(resolve, 6000));

        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
                const links = document.querySelectorAll(
                    'a[href*="/filestore/"], ' +
                    'a[href*="/download/"]'
                );
                return Array.from(links).map(a => ({
                    href: a.href,
                    title: a.textContent.trim() || a.title || ''
                }));
            }
        });

        await chrome.tabs.remove(tab.id);

        let fileItems = results[0]?.result || [];
        console.log(`📎 Найдено файлов (с дублями): ${fileItems.length}`);

        const uniqueByUrl = [];
        const seenUrls = new Set();
        for (const item of fileItems) {
            if (!seenUrls.has(item.href)) {
                seenUrls.add(item.href);
                uniqueByUrl.push(item);
            }
        }
        fileItems = uniqueByUrl;
        console.log(`📎 Уникальных по URL: ${fileItems.length}`);

        if (fileItems.length === 0) {
            console.warn('⚠️ Не найдено файлов dla скачивания');
            return [];
        }

        const files = [];
        let fileCounter = 0;
        const usedNames = new Set();

        for (const item of fileItems) {
            const url = item.href;
            let filename = item.title;

            let blob;
            try {
                const response = await fetch(url, {
                    redirect: 'follow',
                    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
                });
                blob = await response.blob();
            } catch (e) {
                console.error(`❌ Ошибка при скачивании файла: ${url}`, e);
                continue;
            }

            if (blob.type === 'text/html' || blob.size < 50) {
                console.warn(`⚠️ Пропускаем файл (пустой или HTML): ${filename}`);
                continue;
            }

            const detectedExt = await detectExtensionFromBlob(blob);
            console.log(`🔍 Сигнатура: ${detectedExt || 'не определена'}`);

            if (!filename || filename === '' || filename === 'file' || filename.includes('file.html')) {
                const urlParts = url.split('/');
                const lastPart = urlParts[urlParts.length - 1];
                const cleanPart = lastPart.split('?')[0];
                if (cleanPart && cleanPart !== 'file.html' && !cleanPart.includes('file')) {
                    filename = cleanPart;
                } else {
                    fileCounter++;
                    filename = `Документ_${fileCounter}`;
                }
            }

            let baseName = filename;
            let ext = '';
            const dotIndex = filename.lastIndexOf('.');
            if (dotIndex > 0) {
                baseName = filename.substring(0, dotIndex);
                ext = filename.substring(dotIndex);
            }

            if (detectedExt) {
                ext = detectedExt;
            } else {
                const mimeExt = getExtensionFromMimeType(blob.type);
                if (mimeExt) ext = mimeExt;
            }

            let finalName = baseName + ext;
            if (!finalName || finalName === ext) {
                fileCounter++;
                finalName = `Документ_${fileCounter}${ext || ''}`;
            }

            let uniqueName = finalName;
            let suffix = 1;
            while (usedNames.has(uniqueName)) {
                const dotIdx = uniqueName.lastIndexOf('.');
                let namePart = uniqueName;
                let extPart = '';
                if (dotIdx > 0) {
                    namePart = uniqueName.substring(0, dotIdx);
                    extPart = uniqueName.substring(dotIdx);
                }
                uniqueName = `${namePart}_${suffix}${extPart}`;
                suffix++;
            }
            finalName = uniqueName;
            usedNames.add(finalName);

            console.log(`📄 Итоговое имя: ${finalName} (тип: ${blob.type})`);
            files.push({ name: finalName, blob });
        }

        console.log(`📎 Всего скачано уникальных файлов: ${files.length}`);
        return files;
    } catch (e) {
        console.error('❌ Ошибка при загрузке страницы документов:', e);
        return [];
    }
}

// ============================================================
// ОБРАБОТЧИК КНОПКИ "Собрать все тендеры"
// ============================================================

document.getElementById('collectAllBtn')?.addEventListener('click', async () => {
    const status = document.getElementById('status');
    const btn = document.getElementById('collectAllBtn');
    if (!status || !btn) return;

    const access = await checkLicense();
    if (!access) {
        status.textContent = '⚠️ Нет доступа. Введите лицензионный ключ.';
        status.className = 'error';
        showInterface(false);
        return;
    }

    btn.disabled = true;
    status.textContent = '⏳ Собираем тендеры...';
    status.className = 'loading';

    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const response = await chrome.tabs.sendMessage(tab.id, { action: 'collectTenders' });

        if (!response || !response.tenderUrls || response.tenderUrls.length === 0) {
            status.textContent = '❌ Тендеры не найдены на этой странице';
            status.className = 'error';
            btn.disabled = false;
            return;
        }

        const selectedFields = getSelectedFields();
        const maxTenders = parseInt(document.getElementById('maxTenders').value) || 5;

        if (selectedFields.length === 0) {
            status.textContent = '⚠️ Выберите хотя бы один параметр dla анализа';
            status.className = 'error';
            btn.disabled = false;
            return;
        }

        const uniqueTenders = [];
        const seen = new Set();

        for (const url of response.tenderUrls) {
            const regNumber = extractRegNumber(url);
            if (!regNumber) continue;
            if (seen.has(regNumber)) continue;
            seen.add(regNumber);

            const type = getTenderType(url);
            console.log(`🔍 URL: ${url} → Тип: ${type}`);

            if (type === 'unknown') {
                console.warn(`⚠️ Неизвестный тип dla URL: ${url}`);
                continue;
            }
            uniqueTenders.push({ url, type, regNumber });
        }

        console.log(`📊 Найдено уникальных тендеров: ${uniqueTenders.length}`);

        if (uniqueTenders.length === 0) {
            status.textContent = '❌ На странице нет подходящих тендеров';
            status.className = 'error';
            btn.disabled = false;
            return;
        }

        const selectedTenders = uniqueTenders.slice(0, maxTenders);
        status.textContent = `⏳ Обработка ${selectedTenders.length} тендеров...`;
        status.className = 'loading';

        // ---- 1. Анализ печатных форм ----
        status.textContent = `⏳ Анализ печатных форм...`;

        const fetchPromises = selectedTenders.map(async (item) => {
            let formUrl = null;
            if (item.type === '44') {
                formUrl = buildPrintFormUrl44(item.url);
            } else if (item.type === '223') {
                const noticeNum = extractPurchaseNoticeNumber(item.url);
                const guid = extractPurchaseNoticeGuid(item.url);
                if (noticeNum && guid) {
                    formUrl = `https://zakupki.gov.ru/epz/order/notice/notice223/printForm/view.html?purchaseNoticeGuid=${guid}&purchaseNoticeNumber=${noticeNum}`;
                } else {
                    console.warn(`⚠️ Для 223 недостаточно данных в URL: ${item.url}`);
                    return null;
                }
            }
            if (!formUrl) return null;
            const text = await fetchTenderTextByUrl(formUrl);
            if (text && text.length > 100) {
                return {
                    url: item.url,
                    regNumber: item.regNumber,
                    text: text.slice(0, 8000)
                };
            }
            return null;
        });

        const results = await Promise.all(fetchPromises);
        const tendersData = results.filter(item => item !== null);

        let analysisBlob = null;
        if (tendersData.length > 0) {
            const payload = {
                tenders: tendersData,
                fields: selectedFields,
                mode: 'basic'
            };
            try {
                const headers = await getAuthHeaders();
                const response = await fetchWithTimeout(`${LICENSE_SERVER}/analyze_texts`, {
                    method: 'POST',
                    headers: { ...headers, 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                }, 30000, 1);
                if (response.ok) {
                    analysisBlob = await response.blob();
                    console.log(`✅ Анализ печатных форм получен`);
                } else {
                    console.warn('⚠️ Не удалось получить анализ печатных форм');
                }
            } catch (e) {
                console.error('❌ Ошибка при анализе печатных форм:', e);
            }
        }

        // ---- 2. Скачивание документов ----
        let filesBlob = null;
        const downloadFiles = document.getElementById('downloadFilesCheck').checked;
        if (downloadFiles) {
            status.textContent = `⏳ Скачиваем документы...`;
            const allFiles = [];
            for (let i = 0; i < selectedTenders.length; i++) {
                const item = selectedTenders[i];
                status.textContent = `⏳ Обработка тендера ${i+1}/${selectedTenders.length}: ${item.regNumber}...`;

                const docFiles = await fetchAllFiles(item.url, {});
                if (docFiles.length > 0) {
                    allFiles.push({
                        regNumber: item.regNumber,
                        files: docFiles
                    });
                } else {
                    console.warn(`⚠️ Нет документов dla тендера ${item.regNumber}`);
                }

                if (i < selectedTenders.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 300));
                }
            }

            if (allFiles.length > 0) {
                const formData = new FormData();
                for (const tender of allFiles) {
                    tender.files.forEach((file) => {
                        const prefixedName = `${tender.regNumber}_${file.name}`;
                        formData.append('files', file.blob, prefixedName);
                    });
                }
                try {
                    const headers = await getAuthHeaders();
                    const response = await fetchWithTimeout(`${LICENSE_SERVER}/package_files`, {
                        method: 'POST',
                        headers: { ...headers },
                        body: formData
                    }, 30000, 1);
                    if (response.ok) {
                        filesBlob = await response.blob();
                        console.log(`✅ Документы упакованы`);
                    } else {
                        console.warn('⚠️ Не удалось упаковать документы');
                    }
                } catch (e) {
                    console.error('❌ Ошибка при упаковке документов:', e);
                }
            }
        }

        // ---- 3. Скачивание результатов ----
        if (analysisBlob) {
            const link = document.createElement('a');
            link.href = URL.createObjectURL(analysisBlob);
            link.download = `анализ_тендеров_${new Date().toISOString().slice(0,10)}.zip`;
            document.body.appendChild(link);
            link.click();
            link.remove();
            URL.revokeObjectURL(link.href);
            status.textContent = `✅ Анализ печатных форм скачан!`;
            status.className = 'success';
        }

        if (filesBlob) {
            const link = document.createElement('a');
            link.href = URL.createObjectURL(filesBlob);
            link.download = `документы_тендеров_${new Date().toISOString().slice(0,10)}.zip`;
            document.body.appendChild(link);
            link.click();
            link.remove();
            URL.revokeObjectURL(link.href);
            status.textContent = `✅ Документы скачаны!`;
            status.className = 'success';
        }

        if (!analysisBlob && !filesBlob) {
            status.textContent = '❌ Не удалось получить ни анализ, ни документы';
            status.className = 'error';
        }

    } catch (e) {
        status.textContent = `❌ Ошибка: ${e.message}`;
        status.className = 'error';
        console.error('Ошибка:', e);
    } finally {
        btn.disabled = false;
    }
});

// ============================================================
// ОБРАБОТЧИК КНОПКИ "Анализировать текущий"
// ============================================================

document.getElementById('collectSingleBtn')?.addEventListener('click', async () => {
    const status = document.getElementById('status');
    const btn = document.getElementById('collectSingleBtn');
    if (!status || !btn) return;

    const access = await checkLicense();
    if (!access) {
        status.textContent = '⚠️ Нет доступа. Введите лицензионный ключ.';
        status.className = 'error';
        showInterface(false);
        return;
    }

    btn.disabled = true;
    status.textContent = '⏳ Проверяем текущий тендер...';
    status.className = 'loading';

    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const currentUrl = tab.url;

        const regNumber = extractRegNumber(currentUrl);
        const noticeNumber = extractPurchaseNoticeNumber(currentUrl);
        if (!regNumber && !noticeNumber) {
            status.textContent = '❌ Это не страница тендера (не найден номер закупки)';
            status.className = 'error';
            btn.disabled = false;
            return;
        }

        const type = getTenderType(currentUrl);
        console.log(`🔍 Текущий URL: ${currentUrl} → Тип: ${type}`);
        if (type === 'unknown') {
            status.textContent = '❌ Неизвестный тип закупки';
            status.className = 'error';
            btn.disabled = false;
            return;
        }

        const selectedFields = getSelectedFields();
        if (selectedFields.length === 0) {
            status.textContent = '⚠️ Выберите хотя бы один параметр для анализа';
            status.className = 'error';
            btn.disabled = false;
            return;
        }

        // ===== ПОЛУЧАЕМ URL ПЕЧАТНОЙ ФОРМЫ И ДАННЫЕ ДЛЯ ДОКУМЕНТОВ =====
        let formUrl = null;
        let extraParams = {};

        if (type === '44') {
            formUrl = buildPrintFormUrl44(currentUrl);
        } else if (type === '223') {
            let noticeNum = extractPurchaseNoticeNumber(currentUrl);
            let guid = extractPurchaseNoticeGuid(currentUrl);
            if (!noticeNum || !guid) {
                const response = await chrome.tabs.sendMessage(tab.id, { action: 'get223Data' });
                if (response && response.noticeNumber && response.guid) {
                    noticeNum = response.noticeNumber;
                    guid = response.guid;
                    console.log('📥 Получены данные с страницы:', { noticeNum, guid });
                } else {
                    const reg = extractRegNumber(currentUrl);
                    if (reg) {
                        console.warn('⚠️ Используем только regNumber для 223, ссылка может быть неполной');
                        formUrl = `https://zakupki.gov.ru/epz/order/notice/notice223/printForm/view.html?regNumber=${reg}`;
                    } else {
                        status.textContent = '❌ Не удалось получить данные для 223-ФЗ';
                        status.className = 'error';
                        btn.disabled = false;
                        return;
                    }
                }
            }
            if (noticeNum && guid && !formUrl) {
                formUrl = `https://zakupki.gov.ru/epz/order/notice/notice223/printForm/view.html?purchaseNoticeGuid=${guid}&purchaseNoticeNumber=${noticeNum}`;
                extraParams = { noticeNumber: noticeNum, guid: guid };
            }
        }

        if (!formUrl) {
            status.textContent = '❌ Не удалось построить URL печатной формы';
            status.className = 'error';
            btn.disabled = false;
            return;
        }

        const selectedTenders = [{ url: currentUrl, type, regNumber: regNumber || noticeNumber }];
        status.textContent = `⏳ Обработка тендера ${selectedTenders[0].regNumber}...`;
        status.className = 'loading';

        // ---- 1. Анализ печатной формы ----
        status.textContent = `⏳ Анализ печатной формы...`;
        const tendersData = [];
        for (const item of selectedTenders) {
            const text = await fetchTenderTextByUrl(formUrl);
            if (text && text.length > 100) {
                tendersData.push({
                    url: item.url,
                    regNumber: item.regNumber,
                    text: text.slice(0, 8000)
                });
            }
        }

        let analysisBlob = null;
        if (tendersData.length > 0) {
            const payload = {
                tenders: tendersData,
                fields: selectedFields,
                mode: 'basic'
            };
            try {
                const headers = await getAuthHeaders();
                const response = await fetchWithTimeout(`${LICENSE_SERVER}/analyze_texts`, {
                    method: 'POST',
                    headers: { ...headers, 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                }, 30000, 1);
                if (response.ok) {
                    analysisBlob = await response.blob();
                    console.log(`✅ Анализ печатной формы получен`);
                } else {
                    console.warn('⚠️ Не удалось получить анализ');
                }
            } catch (e) {
                console.error('❌ Ошибка при анализе:', e);
            }
        }

        // ---- 2. Скачивание документов ----
        let filesBlob = null;
        const downloadFiles = document.getElementById('downloadFilesCheck').checked;
        if (downloadFiles) {
            status.textContent = `⏳ Скачиваем документы...`;
            const allFiles = [];
            for (const item of selectedTenders) {
                const docFiles = await fetchAllFiles(item.url, extraParams);
                if (docFiles.length > 0) {
                    allFiles.push({
                        regNumber: item.regNumber,
                        files: docFiles
                    });
                } else {
                    console.warn(`⚠️ Нет документов dla тендера ${item.regNumber}`);
                }
            }

            if (allFiles.length > 0) {
                const formData = new FormData();
                for (const tender of allFiles) {
                    tender.files.forEach((file) => {
                        const prefixedName = `${tender.regNumber}_${file.name}`;
                        formData.append('files', file.blob, prefixedName);
                    });
                }
                try {
                    const headers = await getAuthHeaders();
                    const response = await fetchWithTimeout(`${LICENSE_SERVER}/package_files`, {
                        method: 'POST',
                        headers: { ...headers },
                        body: formData
                    }, 30000, 1);
                    if (response.ok) {
                        filesBlob = await response.blob();
                        console.log(`✅ Документы упакованы`);
                    } else {
                        console.warn('⚠️ Не удалось упаковать документы');
                    }
                } catch (e) {
                    console.error('❌ Ошибка при упаковке документов:', e);
                }
            }
        }

        // ---- 3. Скачивание результатов ----
        if (analysisBlob) {
            const link = document.createElement('a');
            link.href = URL.createObjectURL(analysisBlob);
            link.download = `анализ_тендера_${selectedTenders[0].regNumber}_${new Date().toISOString().slice(0,10)}.zip`;
            document.body.appendChild(link);
            link.click();
            link.remove();
            URL.revokeObjectURL(link.href);
            status.textContent = `✅ Анализ скачан!`;
            status.className = 'success';
        }

        if (filesBlob) {
            const link = document.createElement('a');
            link.href = URL.createObjectURL(filesBlob);
            link.download = `документы_тендера_${selectedTenders[0].regNumber}_${new Date().toISOString().slice(0,10)}.zip`;
            document.body.appendChild(link);
            link.click();
            link.remove();
            URL.revokeObjectURL(link.href);
            status.textContent = `✅ Документы скачаны!`;
            status.className = 'success';
        }

        if (!analysisBlob && !filesBlob) {
            status.textContent = '❌ Не удалось получить ни анализ, ни документы';
            status.className = 'error';
        }

    } catch (e) {
        status.textContent = `❌ Ошибка: ${e.message}`;
        status.className = 'error';
        console.error('Ошибка:', e);
    } finally {
        btn.disabled = false;
    }
});
